'use strict';

/**
 * Config constant
 */
app.constant('APP_MEDIAQUERY', {
    'desktopXL': 1200,
    'desktop': 992,
    'tablet': 768,
    'mobile': 480
});

//*** Static variable showing the execution path
app.constant('CONFIG', {
    APIURL: "http://localhost:9080"
});

app.constant('JS_REQUIRES', {
    //*** Scripts
    scripts: {
        //*** Javascript Plugins
        'modernizr': ['../bower_components/modernizr/modernizr.js'],
        'moment': ['../bower_components/moment/min/moment.min.js'],
        'spin': '../bower_components/spin.js/spin.js',

        //*** Controllers
        'clothesCtrl': 'public/js/controllers/clothesCtrl.js',
        'shoptCtrl': 'public/js/controllers/shopCtrl.js',
        
        //*** Factorys
        'clothes': 'public/js/factories/clothes.js',
        'shop': 'public/js/factories/shop.js'
    }
});
