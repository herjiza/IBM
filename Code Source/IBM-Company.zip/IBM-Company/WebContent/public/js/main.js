var app = angular.module('test-ibm', ['ibm']);

app.run(['$rootScope',
function ($rootScope) {

    // GLOBAL APP SCOPE
    // Set below basic information
    $rootScope.app = {
        company: 		'Phoenix',	 												// Name of company
        author: 		'Hernando Jimenez Zambrano', 								// Author's name 
        description: 	'Fabrica De Ropa', 											// Brief description
        version: 		'1.1', 														// Current version
        favi: 			'public/images/logo/favi.png',								// FaviIcon Page
        logo: 			'public/images/logo/phoenix.png',						// Logo Company
        year: ((new Date()).getFullYear()), 										// Automatic current year (for copyright information)
        isMobile: (function () {													// True if the browser is a mobile device
            var check = false;
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                check = true;
            };
            return check;
        })()
    };


}]);
