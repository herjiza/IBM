'use strict';


app.controller('clothesCtrl', function($scope){
	
	$scope.quantity = 0;
	$scope.subTotal = 0;
	$scope.total = 0;
	$scope.incrementShipping = 0;
	
	// In this array save the clothes to query data base
	$scope.typeClothes = [
        {
            "id":			0,
            "name": 		"Pantalones",
            "description":	"Pantalones Formales",
            clothes:[
                {
                    "id":			1,
                    "name": 		"Pantalon V34",
                    "description":	"Pantalon En Lino",
                    image : {
                    	"url":		"public/images/clothes/cat-1.jpg",
                    	"mime":		"image/jpg"
                    },
                    "price":		63500,
                    "quantity":		0
                },
                {
                    "id":			1,
                    "name": 		"Pantalon Lion - V2",
                    "description":	"Pantalon Para La Oficina",
                    image : {
                    	"url":		"public/images/clothes/cat-3.jpg",
                    	"mime":		"image/jpg"
                    },
                    "price":		56500,
                    "quantity":		0
                }
            ]
        },
        {
            "id":			1,
            "name": 		"Conjunto Sport",
            "description":	"Conjunto De Ropa Completo",
            clothes:[
                {
                    "id":			1,
                    "name": 		"Conjunto Oficina",
                    "description":	"Conjunto Sport Para OFicina",
                    image : {
                    	"url":		"public/images/clothes/cat-5.jpg",
                    	"mime":		"image/jpg"
                    },
                    "price":		98000,
                    "quantity":		0
                }
            ]
        }
    ];
	
	// Show in the form the states and asociate the citys
	$scope.states = [
        {
            "id":			0,
            "name": 		"Antioquia",
            "code":			"6",
            "citys":[
                {
                    "id":			0,
                    "name": 		"Medellín",
                    "shippingCost":	0
                }
            ]
        },
        {
            "id":			1,
            "name": 		"Valle Del Cauca",
            "code":			"2",
            "citys":[
                {
                    "id":			0,
                    "name": 		"Santiago De Cali",
                    "shippingCost":	10
                },
                {
                    "id":			1,
                    "name": 		"Palmira",
                    "shippingCost":	11
                }
            ]
        }
    ];
	
	// Type identification
	$scope.typeIdentification = [
        {
            "id":			0,
            "name": 		"Cedula De Ciudadania"
        },
        {
            "id":			1,
            "name": 		"Cedula De Extranjeria"
        },
        {
            "id":			2,
            "name": 		"Numero Identificación Tributaria"
        }
    ];
	
	$scope.client = {
		name: 				"",
	    lastName: 			"",
	    address: 			"",
	    identificationNumber: "",
	    dateDelivery:		"",
	    stateDelivery:		0,
	    cityDelivery:		0,
	    typeIdentification:	"",
	    dateDelivery:		""
	};
	
	$scope.validate = function () {
		
		$scope.quantity = 0;
		$scope.subTotal = 0;
		$scope.total = 0;
		$scope.incrementShipping = $scope.states[$scope.client.stateDelivery].citys[$scope.client.cityDelivery].shippingCost;
		  
		for(var i = 0; i < $scope.typeClothes.length; i++)
			for(var k = 0; k < $scope.typeClothes[i].clothes.length; k++){
				$scope.subTotal += ($scope.typeClothes[i].clothes[k].quantity * $scope.typeClothes[i].clothes[k].price);
				$scope.quantity += $scope.typeClothes[i].clothes[k].quantity;
			}

		$scope.total = $scope.subTotal + (($scope.subTotal * $scope.incrementShipping)/100);
		
		if($scope.quantity  > 5)
			alert("Solo Puede Registrar Hasta 5 Productos");
    };
    
    $scope.shop = function () {
		
		console.log("Client Name: " + $scope.client.name);
		console.log("Client Last Name: " + $scope.client.lastName);
		console.log("Identification Number: " + $scope.client.identificationNumber);
		console.log("Type Identification: " + $scope.client.typeIdentification);
		console.log("City: " + $scope.states[$scope.client.stateDelivery].citys[$scope.client.cityDelivery].name);
		console.log("Date Delivery: " + $scope.client.dateDelivery);
		console.log("Address: " + $scope.client.address);
		console.log("Quantity Clothes: " + $scope.quantity);
		console.log("SubTotal: " + $scope.subTotal);
		console.log("Increment For Shipping: " + $scope.incrementShipping);
		console.log("Total: " + $scope.total);
    };
});