app.run(['$rootScope',
function ($rootScope) {

    // Set below basic resources of the theme
    $rootScope.theme = {
    	logo: {
    		light:	'public/images/logo/phoenix.png',
    		dark:	'public/images/logo/phoenix.png'
    	},
    	ibm:		'public/images/logo/IBM.png'
    	
    };


}]);
