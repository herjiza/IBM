/**
 * 
 */

function loadJSP(jsp) {

	$.ajax({
        type: 'POST',
        url: jsp,
        data : $(this).serialize(),
        success: function(response) {
        	$('#content-page').append(response);
        	
        	
        }
    });
}
