/**
  * declare 'ibm' module with dependencies
*/
'use strict';
angular.module("ibm", []);
