package company;

public class Client {

	private String name;
	private String lastName;
	private String identificationNumber;
	private String typeIdentificacion;
	private String address;
	private String phone;
	private String mobile;
	private String dateDelivery;
	private String cityDelivery;
	
	// Constructor of the class
	public Client(String name, String lastName, String identificationNumber, String typeIdentificacion, String address,
			String phone, String mobile, String dateDelivery, String cityDelivery) {
		super();
		this.name = name;
		this.lastName = lastName;
		this.identificationNumber = identificationNumber;
		this.typeIdentificacion = typeIdentificacion;
		this.address = address;
		this.phone = phone;
		this.mobile = mobile;
		this.dateDelivery = dateDelivery;
		this.cityDelivery = cityDelivery;
	}

	// Start Setters and Getters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIdentificationNumber() {
		return identificationNumber;
	}

	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	public String getTypeIdentificacion() {
		return typeIdentificacion;
	}

	public void setTypeIdentificacion(String typeIdentificacion) {
		this.typeIdentificacion = typeIdentificacion;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateDelivery() {
		return dateDelivery;
	}

	public void setDateDelivery(String dateDelivery) {
		this.dateDelivery = dateDelivery;
	}

	public String getCityDelivery() {
		return cityDelivery;
	}

	public void setCityDelivery(String cityDelivery) {
		this.cityDelivery = cityDelivery;
	}

	// End Setters and Getters

	
	
}
