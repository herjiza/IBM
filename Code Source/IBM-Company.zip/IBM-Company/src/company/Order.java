package company;

import java.util.ArrayList;

public class Order {

	// Object type client
	private Client client;

	// Array with all the products choise
	private ArrayList <Clothes> clothes = new ArrayList<Clothes>();;
	
	// increment of the delivery for change city to send
	private double incrementDelivery;
	
	// another information
	private String dateDelivery;
	private String cityDelivery;
	
	public Order(Client client, ArrayList<Clothes> clothes, double incrementDelivery, String dateDelivery,
			String cityDelivery) {
		super();
		this.client = client;
		this.clothes = clothes;
		this.incrementDelivery = incrementDelivery;
		this.dateDelivery = dateDelivery;
		this.cityDelivery = cityDelivery;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public ArrayList<Clothes> getClothes() {
		return clothes;
	}

	public void setAds(ArrayList<Clothes> clothes) {
		this.clothes = clothes;
	}

	public double getIncrementDelivery() {
		return incrementDelivery;
	}

	public void setIncrementDelivery(double incrementDelivery) {
		this.incrementDelivery = incrementDelivery;
	}

	public String getDateDelivery() {
		return dateDelivery;
	}

	public void setDateDelivery(String dateDelivery) {
		this.dateDelivery = dateDelivery;
	}

	public String getCityDelivery() {
		return cityDelivery;
	}

	public void setCityDelivery(String cityDelivery) {
		this.cityDelivery = cityDelivery;
	}
	
	
}
