package shop;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.inject.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import company.Clothes;

@Path("/shop")
public class ShopService {
	
	// a database
	private static List<Clothes> clothes_1 = new ArrayList<Clothes>();
	static {
		clothes_1.add(new Clothes(1, "Pantalon V34", "Pantalon Formal Para Oficina", 63500, 0));
		clothes_1.add(new Clothes(1, "Pantalon Lion - V2", "Pantalon Sport", 56500, 0));
	}
	
	private static List<Clothes> clothes_2 = new ArrayList<Clothes>();
	static {
		clothes_2.add(new Clothes(1, "Conjunto Oficina", "Conjunto Fresco Para La Oficina", 98000, 0));
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Clothes> getClothes_1() {
		return clothes_1;
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Clothes> getClothes_2() {
		return clothes_2;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/products")
	public String clothers() {
		return "s";
	}
	
	@GET
	@Path("/{Products},{quantity}")
	public String buy() {
		return "Compra Realizada!";
	}
}
