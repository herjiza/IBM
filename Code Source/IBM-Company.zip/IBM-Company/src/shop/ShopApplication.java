package shop;

public class ShopApplication {

}
